"""
zepz_migrate_to_databricks.py
==============================
Migrates all 5 Zepz audit tables from a local SQLite database into
Databricks Unity Catalog (main.zepz.*).

Tables migrated:
  customers     (~500 rows)
  transactions  (5,000 rows)
  disclosures   (5,000 rows)
  audit_events  (37,568 rows)
  violations    (2,568 rows)

Prerequisites:
  pip install databricks-sql-connector

Usage:
  python zepz_migrate_to_databricks.py \
    --sqlite /path/to/zepz_audit.db \
    --host   <databricks-host> \
    --token  <personal-access-token> \
    --warehouse <sql-warehouse-id>
"""

import argparse
import sqlite3
import time
import sys
from datetime import datetime

try:
    from databricks import sql as dbsql
except ImportError:
    print("ERROR: databricks-sql-connector not installed.")
    print("  Run: pip install databricks-sql-connector")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
CATALOG   = "main"
SCHEMA    = "zepz"
CHUNK     = 500        # rows per INSERT batch

TABLES = [
    "customers",
    "transactions",
    "disclosures",
    "audit_events",
    "violations",
]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def ts():
    return datetime.now().strftime("%H:%M:%S")

def log(msg):
    print(f"[{ts()}] {msg}", flush=True)

def sqlite_connect(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn

def db_connect(host: str, token: str, warehouse_id: str):
    return dbsql.connect(
        server_hostname = host,
        http_path       = f"/sql/1.0/warehouses/{warehouse_id}",
        access_token    = token,
        catalog         = CATALOG,
        schema          = SCHEMA,
    )

def quote_val(v):
    """Safely quote a single value for an INSERT VALUES list."""
    if v is None:
        return "NULL"
    s = str(v).replace("'", "''")
    return f"'{s}'"

def build_insert(table: str, columns: list[str], rows: list) -> str:
    col_list = ", ".join(columns)
    val_rows = []
    for row in rows:
        vals = ", ".join(quote_val(row[c]) for c in columns)
        val_rows.append(f"({vals})")
    return (
        f"INSERT INTO {CATALOG}.{SCHEMA}.{table} ({col_list})\n"
        f"VALUES\n" + ",\n".join(val_rows)
    )

# ---------------------------------------------------------------------------
# Core migration
# ---------------------------------------------------------------------------
def migrate_table(
    src_conn: sqlite3.Connection,
    dst_cursor,
    table: str,
    truncate_first: bool = True,
) -> int:
    log(f"  → Starting table: {table}")

    # Get column names from SQLite
    cur = src_conn.execute(f"SELECT * FROM {table} LIMIT 1")
    columns = [d[0] for d in cur.description]

    # Optionally truncate destination first (idempotent re-runs)
    if truncate_first:
        log(f"    Truncating {CATALOG}.{SCHEMA}.{table}...")
        dst_cursor.execute(f"DELETE FROM {CATALOG}.{SCHEMA}.{table}")

    # Get total rows
    total = src_conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
    log(f"    {total:,} rows to migrate in chunks of {CHUNK}")

    loaded  = 0
    offset  = 0
    t_start = time.time()

    while offset < total:
        rows = src_conn.execute(
            f"SELECT * FROM {table} LIMIT {CHUNK} OFFSET {offset}"
        ).fetchall()

        if not rows:
            break

        sql = build_insert(table, columns, rows)
        dst_cursor.execute(sql)

        loaded += len(rows)
        offset += CHUNK
        elapsed = time.time() - t_start
        pct = loaded / total * 100
        rps = loaded / elapsed if elapsed > 0 else 0
        log(f"    {loaded:>6,}/{total:,} ({pct:5.1f}%)  {rps:.0f} rows/s")

    elapsed = time.time() - t_start
    log(f"  ✓ {table}: {loaded:,} rows in {elapsed:.1f}s")
    return loaded

# ---------------------------------------------------------------------------
# Verification
# ---------------------------------------------------------------------------
def verify(dst_cursor, sqlite_conn) -> bool:
    log("\nVerification:")
    all_ok = True
    for table in TABLES:
        sqlite_cnt = sqlite_conn.execute(
            f"SELECT COUNT(*) FROM {table}"
        ).fetchone()[0]
        dst_cursor.execute(
            f"SELECT COUNT(*) AS cnt FROM {CATALOG}.{SCHEMA}.{table}"
        )
        dbx_cnt = dst_cursor.fetchone()[0]
        status = "✓" if dbx_cnt == sqlite_cnt else "✗ MISMATCH"
        log(f"  {status}  {table:<20} SQLite={sqlite_cnt:>6,}  Databricks={dbx_cnt:>6,}")
        if dbx_cnt != sqlite_cnt:
            all_ok = False
    return all_ok

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Migrate Zepz SQLite → Databricks")
    parser.add_argument("--sqlite",    required=True,  help="Path to SQLite .db file")
    parser.add_argument("--host",      required=True,  help="Databricks workspace hostname")
    parser.add_argument("--token",     required=True,  help="Databricks personal access token")
    parser.add_argument("--warehouse", required=True,  help="SQL Warehouse ID")
    parser.add_argument("--no-truncate", action="store_true",
                        help="Skip truncating destination tables before loading")
    args = parser.parse_args()

    log("=" * 60)
    log("Zepz SQLite → Databricks Migration")
    log(f"  Source : {args.sqlite}")
    log(f"  Target : {CATALOG}.{SCHEMA}")
    log(f"  Host   : {args.host}")
    log("=" * 60)

    t0 = time.time()

    # Open connections
    log("\nOpening SQLite connection...")
    sqlite_conn = sqlite_connect(args.sqlite)

    log("Opening Databricks connection...")
    db_conn   = db_connect(args.host, args.token, args.warehouse)
    db_cursor = db_conn.cursor()

    # Migrate each table
    log("\nMigrating tables...")
    totals = {}
    for table in TABLES:
        totals[table] = migrate_table(
            sqlite_conn,
            db_cursor,
            table,
            truncate_first = not args.no_truncate,
        )

    # Verify row counts
    ok = verify(db_cursor, sqlite_conn)

    # Cleanup
    db_cursor.close()
    db_conn.close()
    sqlite_conn.close()

    elapsed = time.time() - t0
    grand_total = sum(totals.values())
    log(f"\n{'='*60}")
    log(f"Migration {'COMPLETE ✓' if ok else 'COMPLETED WITH ERRORS ✗'}")
    log(f"  Total rows : {grand_total:,}")
    log(f"  Total time : {elapsed:.1f}s")
    log(f"{'='*60}")

    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
